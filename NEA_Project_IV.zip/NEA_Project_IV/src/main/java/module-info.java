module org.example.nea_project_iii {

    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.sql;
    requires org.xerial.sqlitejdbc;
    requires java.desktop;

    exports org.example.nea_project_iii.Question_Map;
    exports org.example.nea_project_iii.Behind_The_Scenes;
    exports org.example.nea_project_iii.Main_Menu;
    exports org.example.nea_project_iii.Log_In;
    exports org.example.nea_project_iii.Settings;
    exports org.example.nea_project_iii.Introduction;
    exports org.example.nea_project_iii.Results;
    exports org.example.nea_project_iii.Exercises_Topic1;

    opens org.example.nea_project_iii.Log_In to javafx.fxml;
    opens org.example.nea_project_iii.Settings to javafx.fxml;
    opens org.example.nea_project_iii.Question_Map to javafx.fxml;
    opens org.example.nea_project_iii.Main_Menu to javafx.fxml;
    opens org.example.nea_project_iii.Introduction to javafx.fxml;
    opens org.example.nea_project_iii.Behind_The_Scenes to javafx.fxml;
    opens org.example.nea_project_iii.Results to javafx.fxml;
    opens org.example.nea_project_iii.Exercises_Topic1 to javafx.fxml;

}