package org.example.nea_project_iii.Main_Menu;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import org.example.nea_project_iii.Behind_The_Scenes.SceneManager;


public class MainMenuConfirm {
    public Label confirmationText;

    @FXML
    public void Confirm_Button() {
        if (MainMenuController.menu_choice == 0) {
            SceneManager.SwitchToQuestionMap();
        } else if (MainMenuController.menu_choice == 1) {
            SceneManager.SwitchToSettings();
        } else if (MainMenuController.menu_choice == 2) {
            SceneManager.SwitchToLogIn();
        }
    }


    @FXML
    public void Reject_Button() {
        SceneManager.SwitchToMainMenu();
    }
}
