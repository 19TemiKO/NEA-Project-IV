package org.example.nea_project_iii.Behind_The_Scenes;

public enum AccountType {
    GUEST, PERMANENT
}

