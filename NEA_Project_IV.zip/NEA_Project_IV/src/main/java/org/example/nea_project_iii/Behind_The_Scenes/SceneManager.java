package org.example.nea_project_iii.Behind_The_Scenes;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class SceneManager {

    private static Stage primaryStage;

    public static void setStage(Stage stage) {
        primaryStage = stage;

    }



    public static void SwitchToLogIn() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    SceneManager.class.getResource(
                            "/org/example/nea_project_iii/FXML_Folder/log-in-view.fxml"
                    )
            );
            Scene scene = new Scene(loader.load());
            primaryStage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public static void SwitchToMainMenu() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    SceneManager.class.getResource(
                            "/org/example/nea_project_iii/FXML_Folder/main-menu-view.fxml"
                    )
            );

            Scene scene = new Scene(loader.load());
            primaryStage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public static void SwitchToQuestionMap() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    SceneManager.class.getResource(
                            "/org/example/nea_project_iii/FXML_Folder/question-map-view.fxml"
                    )
            );

            Scene scene = new Scene(loader.load());
            primaryStage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public static void SwitchToSettings() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    SceneManager.class.getResource(
                            "/org/example/nea_project_iii/FXML_Folder/settings-view.fxml"
            )
        );

            Scene scene = new Scene(loader.load());
            primaryStage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }




    public static void SwitchToMainMenuConfirmation() { //rename this
        try {
            FXMLLoader loader = new FXMLLoader(
                    SceneManager.class.getResource(
                            "/org/example/nea_project_iii/FXML_Folder/main-menu-confirm.fxml"
                    )
            );

            Scene scene = new Scene(loader.load());
            primaryStage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public static void SwitchToIntroduction() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    SceneManager.class.getResource(
                            "/org/example/nea_project_iii/FXML_Folder/intro-view.fxml"
            ));

            Scene scene = new Scene(loader.load());
            primaryStage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void SwitchToQuestionMapConfirmation() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    SceneManager.class.getResource(
                            "/org/example/nea_project_iii/FXML_Folder/question-map-confirm.fxml"
                    ));

            Scene scene = new Scene(loader.load());
            primaryStage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void SwitchToUserDetails() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    SceneManager.class.getResource(
                            "/org/example/nea_project_iii/FXML_Folder/settings-user-details.fxml"
                    )
            );
            Scene scene = new Scene(loader.load());
            primaryStage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public static void SwitchToResults() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    SceneManager.class.getResource(
                            "/org/example/nea_project_iii/FXML_Folder/results-view.fxml"
                    )
            );
            Scene scene = new Scene(loader.load());
            primaryStage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void SwitchToTopic1() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    SceneManager.class.getResource(
                            "/org/example/nea_project_iii/FXML_Folder/question-layout1.fxml"
                    ));

            Scene scene = new Scene(loader.load());
            primaryStage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void ChangeGraphics(boolean light_mode_on) {
        Scene scene = primaryStage.getScene();
        scene.getStylesheets().clear();

            if (light_mode_on) {
                scene.getStylesheets().add(
                        SceneManager.class.getResource(
                                "/org/example/nea_project_iii/CSS_Folder/light-mode.css"
                        ).toExternalForm()
                );
            } else {
                scene.getStylesheets().add(
                        SceneManager.class.getResource(
                                "/org/example/nea_project_iii/CSS_Folder/dark-mode.css"
                        ).toExternalForm()
                );
            }
        }


    }