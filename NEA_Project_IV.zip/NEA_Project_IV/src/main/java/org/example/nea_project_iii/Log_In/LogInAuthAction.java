package org.example.nea_project_iii.Log_In;

public enum LogInAuthAction {
    LOGIN, REGISTER, GUEST
}