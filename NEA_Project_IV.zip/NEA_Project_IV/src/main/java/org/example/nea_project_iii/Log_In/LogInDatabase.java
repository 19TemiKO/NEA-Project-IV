package org.example.nea_project_iii.Log_In;
import org.example.nea_project_iii.Behind_The_Scenes.DatabaseLocation;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.sql.*;

public class LogInDatabase {

    @FXML protected PasswordField password;
    @FXML protected TextField username;
    @FXML public Label defaultText;
    @FXML public Label verificationText;




    public boolean new_user(String new_username, String new_password) throws SQLException {
        String[] new_details = LogInEncryption.EncryptionAlgorithm(new_username, new_password);

        new_username = new_details[1];
        new_password = new_details[0];


        String new_user_sql = "INSERT INTO users (password, username) VALUES (?, ?)";
        try (PreparedStatement new_user_prepared_statement = DatabaseLocation.getConnection().prepareStatement(new_user_sql)) {

            new_user_prepared_statement.setString(1, new_password);
            new_user_prepared_statement.setString(2, new_username);

            int rows = new_user_prepared_statement.executeUpdate();
            try (PreparedStatement check = DatabaseLocation.getConnection().prepareStatement(
                    "SELECT user_id, username FROM users WHERE username = ?")) {
                check.setString(1, new_username);


                String populate_sql = "INSERT INTO user_progress (topic1_difficulty, topic2_difficulty, topic3_difficulty) VALUES (?, ?, ?)";
                try (PreparedStatement populate_statement = DatabaseLocation.getConnection().prepareStatement(populate_sql)) {

                    populate_statement.setInt(1, 1);
                    populate_statement.setInt(2, 1);
                    populate_statement.setInt(3, 1);


                    return rows == 1;

                } catch (SQLException e) {
                    throw e;
                }
            }
        }

    }



    public LogInAuthResult verification(String username_verify, String password_verify) throws SQLException {
        String[] new_details = LogInEncryption.EncryptionAlgorithm(username_verify, password_verify);
        password_verify = new_details[0];
        username_verify = new_details[1];


        String verify_sql = "SELECT user_id FROM users WHERE username = ? AND password = ?";

        try (PreparedStatement verify_statement = DatabaseLocation.getConnection().prepareStatement(verify_sql)) {
            verify_statement.setString(1, username_verify);
            verify_statement.setString(2, password_verify);

            try (ResultSet verify_resultset = verify_statement.executeQuery()) {
                if (!verify_resultset.next()) {
                    return LogInAuthResult.log_in_fail("Username not found");
                }

                int user_id = verify_resultset.getInt("user_id");

                return LogInAuthResult.log_in_success(user_id);
            }
        }
    }
}
