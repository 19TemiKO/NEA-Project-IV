package org.example.nea_project_iii.Settings;

import org.example.nea_project_iii.Behind_The_Scenes.SceneManager;

public class SettingsController {

    int times_pressed = 0;
    public static boolean light_mode = true;

    public void ChangeUserDetails() {
        SceneManager.SwitchToUserDetails();
    }

    public void GraphicsToggle() {
        times_pressed = times_pressed + 1;
        light_mode = times_pressed % 2 != 0;
        SceneManager.ChangeGraphics (light_mode);
    }

    public void Back() {
        SceneManager.SwitchToMainMenu();
    }

}
