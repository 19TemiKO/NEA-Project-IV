package org.example.nea_project_iii.Settings;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import org.example.nea_project_iii.Behind_The_Scenes.AccountType;
import org.example.nea_project_iii.Behind_The_Scenes.SceneManager;
import org.example.nea_project_iii.Behind_The_Scenes.UserInfo;
import org.example.nea_project_iii.Log_In.LogInAuthAction;

import java.sql.SQLException;


public class SettingsUserDetails {

    @FXML
    private TextField new_username;

    @FXML
    private PasswordField new_password;

    @FXML
    private Label defaultText;

    @FXML
    public void ConfirmButton() {
        AccountType type = UserInfo.get_account_type();
        LogInAuthAction mode = UserInfo.get_account_mode();

        String old_username = UserInfo.get_username();
        String old_password = UserInfo.get_password();
        String username_input = this.new_username.getText().trim();
        String password_input = this.new_password.getText().trim();

        if (type == AccountType.GUEST && mode == LogInAuthAction.GUEST || old_password == null || old_username == null) {
            new_password.setDisable(true);
            new_username.setDisable(true);
            defaultText.setText("You have a Guest Account: you cannot change details you don't have.");

        } else {



            if (old_username.isEmpty() || old_password.isEmpty()
                    || username_input.isEmpty() || password_input.isEmpty()) {

                defaultText.setText("All fields must be filled.");
                return; // Checks if the user input is empty
            }

            try {
                boolean updated = SettingsDatabase.update_details(
                        username_input, password_input,
                        old_username, old_password);

                if (updated) {
                    defaultText.setText("Details updated successfully.");
                    this.new_username.clear();
                    this.new_password.clear();

                } else {
                    defaultText.setText("Incorrect username or password.");
                }

            } catch (SQLException e) {

                if (e.getMessage().contains("UNIQUE")) {
                    defaultText.setText("Username already exists.");
                } else {
                    defaultText.setText("Database error.");
                    e.printStackTrace();
                }
            }
        }
    }



    @FXML
    public void RejectButton() {
        SceneManager.SwitchToSettings();
    }

    }