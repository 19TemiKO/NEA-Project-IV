package org.example.nea_project_iii.Question_Map;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import org.example.nea_project_iii.Behind_The_Scenes.SceneManager;

public class QuestionMapConfirm {
    public Label confirmationText;

    @FXML public void Confirm_Button() {
        if (QuestionMapController.section_choice == 1) {
            SceneManager.SwitchToTopic1();

        } else if (QuestionMapController.section_choice == 2) {
            SceneManager.SwitchToQuestionMap(); // Unfinished

        } else if (QuestionMapController.section_choice == 3) {
            SceneManager.SwitchToQuestionMap(); // Unfinished

        } else if (QuestionMapController.section_choice == 4) {
            SceneManager.SwitchToMainMenu();
        }
    }


    @FXML
    public void Reject_Button() {
        SceneManager.SwitchToMainMenu();
    }
}