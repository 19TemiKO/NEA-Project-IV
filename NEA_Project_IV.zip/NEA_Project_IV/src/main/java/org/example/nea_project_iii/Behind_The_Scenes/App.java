package org.example.nea_project_iii.Behind_The_Scenes;

import javafx.application.Application;
import javafx.stage.Stage;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class App extends Application {

//    public static String test() throws SQLException {
//    String not_in_database_sql = "SELECT users.username, users.password FROM users WHERE user_id = 8";
//
//    PreparedStatement test_statement = DatabaseLocation.getConnection().prepareStatement(not_in_database_sql); {
//        ResultSet rs = test_statement.executeQuery();
//        while (rs.next()) {
//
//            String username = rs.getString("username");
//            String password = rs.getString("password");
//
//            System.out.printf("Username: " + username);
//            System.out.println(" is new_account hashed");
//            System.out.printf("Password: " + password);
//            System.out.println(" is new_account hashed");
//        }
//
//    }
//
//        return not_in_database_sql;
//}



    public void start(Stage stage) {
        SceneManager.setStage(stage);
        SceneManager.SwitchToLogIn();

        stage.setTitle("[ Japanese Basics ]");
        stage.show();
    }



    public static void main(String[] args) throws SQLException {
//        test();
        launch(args);
    }
}