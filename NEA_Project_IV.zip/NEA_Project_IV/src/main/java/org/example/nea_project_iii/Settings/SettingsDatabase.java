package org.example.nea_project_iii.Settings;

import org.example.nea_project_iii.Behind_The_Scenes.DatabaseLocation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SettingsDatabase {

    public static boolean update_details(String new_username, String new_password,
                                         String old_username, String old_password) throws SQLException {

        String update_sql = """
            UPDATE users
            SET username = ?, password = ?
            WHERE username = ? AND password = ?
        """;

        // Hashes the input
        String hashed_new_username = SettingsEncryption.EncryptionAlgorithm(new_username.trim());
        String hashed_new_password = SettingsEncryption.EncryptionAlgorithm(new_password.trim());

        try (Connection connection = DatabaseLocation.getConnection();
             PreparedStatement update_ps = connection.prepareStatement(update_sql)) {

            update_ps.setString(1, hashed_new_username);
            update_ps.setString(2, hashed_new_password);

            // Places the hashed input where the old details are
            update_ps.setString(3, old_username);
            update_ps.setString(4, old_password);

            int rows = update_ps.executeUpdate();

            return rows > 0;
        }
    }
}