package org.example.nea_project_iii.Exercises_Topic1;

public class Topic1Question {
    public int question_id;
    public String question;
    public String correct;
    public String incorrect1;
    public String incorrect2;
    public String incorrect3;
    public String question_type;


public Topic1Question(int question_id, String question, String correct,
        String incorrect1, String incorrect2, String incorrect3, String question_type) {

        this.question_id = question_id;
        this.question = question;
        this.correct = correct;
        this.incorrect1 = incorrect1;
        this.incorrect2 = incorrect2;
        this.incorrect3 = incorrect3;
        this.question_type = question_type;
    }


    public int get_id() {
        return question_id; }
    public String get_question() {
        return question; }
    public String get_correct() {
        return correct; }
    public String get_incorrect1() {
        return incorrect1; }
    public String get_incorrect2() {
        return incorrect2; }
    public String get_incorrect3() {
        return incorrect3; }
    public String get_question_type() {
        return question_type;}
}
