package org.example.nea_project_iii.Results;

import org.example.nea_project_iii.Behind_The_Scenes.AdaptiveAlgorithm;
import org.example.nea_project_iii.Behind_The_Scenes.SceneManager;
import org.example.nea_project_iii.Behind_The_Scenes.UserInfo;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Button;


public class ResultsController {
    @FXML
    private Label question_label;
    @FXML
    private Button progress;


    @FXML
    public void initialize() {
        int good_streak = AdaptiveAlgorithm.get_winning_streak();

        int difficulty = UserInfo.get_last_difficulty();
        question_label.setText(
                    "Exercise Complete!\n\n" +
                            "You achieved: " + get_difficulty_name (difficulty) + " difficulty!\n" +
                            "Your streak was: " + good_streak
            );
        }


    public String get_difficulty_name (Integer difficulty_name) {
        if (difficulty_name == 0) {
            return "Easy";
        }else if (difficulty_name == 1) {
            return "Medium";}
        else if (difficulty_name == 2) {
            return "Hard";
        }
    return "Error";
    }


    @FXML
    public void leave() {
        SceneManager.SwitchToMainMenu();
    }
}