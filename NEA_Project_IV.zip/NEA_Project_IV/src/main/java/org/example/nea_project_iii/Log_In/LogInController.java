package org.example.nea_project_iii.Log_In;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;

import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import org.example.nea_project_iii.Behind_The_Scenes.AccountType;
import org.example.nea_project_iii.Behind_The_Scenes.SceneManager;

import javafx.fxml.FXML;
import org.example.nea_project_iii.Behind_The_Scenes.UserInfo;

import java.sql.SQLException;


public class LogInController extends LogInDatabase {

    @FXML private Button Guest_Account_Button;
    @FXML private Button Log_In_Button;
    @FXML private Button New_Account_Button;
    @FXML public TextField username;
    @FXML public PasswordField password;
    @FXML private Label verificationText;
    @FXML private Label defaultText;
    public static LogInAuthAction account_mode = LogInAuthAction.LOGIN;
    public static AccountType account_type = AccountType.PERMANENT;
    public LogInAuthResult verified;
    public boolean new_account_made;


    @FXML
    private void initialise() {
        set_mode(LogInAuthAction.LOGIN);
        // Assumes the user is logging into the app.
        // This can be changed depending on user input.
    }


    @FXML
    public void Confirm_Click(ActionEvent event) {

        if (account_mode == LogInAuthAction.LOGIN) {
            try {
                verified = verification(username.getText(), password.getText());
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

            if (verified.success()) {

                account_type = AccountType.PERMANENT;
                UserInfo.set_current_user_id(verified.user_id());
                UserInfo.set_username(username.getText());
                UserInfo.set_password(password.getText());
                UserInfo.set_account_type(account_type);
                UserInfo.set_account_mode(account_mode);

                SceneManager.SwitchToMainMenu();

            } else {
                verificationText.setText("Incorrect username or password.");
            }


        } else if (account_mode == LogInAuthAction.REGISTER) {

            try {
                new_account_made = new_user(username.getText(), password.getText());

                if (new_account_made) {
                    verificationText.setText("Registration successful.");
                } else {
                    verificationText.setText("Registration unsuccessful.");
                }
            } catch (SQLException e) {
                if (e.getMessage().contains("SQLITE_CONSTRAINT_UNIQUE")) {
                    verificationText.setText("That username already exists.");
                    // I came across this in testing and decided to make this a feature.
                        // As in telling the user the username they've entered already exists.
                }
            }

        } else if (account_type == AccountType.GUEST && account_mode == LogInAuthAction.GUEST) {
            SceneManager.SwitchToIntroduction();
        }
    }



    private void set_mode(LogInAuthAction new_mode) {
        account_mode = new_mode;

        if (LogInAuthAction.LOGIN.equals(new_mode)) {
            defaultText.setText("Enter your log-in details.");

        }else if (LogInAuthAction.REGISTER.equals(new_mode)) {
            defaultText.setText("Enter your registration details.");
        }else {
           throw new RuntimeException();
        }
    }


    private void set_account_type(AccountType new_account) {
        account_type = new_account;

        if (AccountType.GUEST.equals(new_account)) {
            defaultText.setText("Your progress will not be saved.");
            account_type = AccountType.GUEST;
            account_mode = LogInAuthAction.GUEST;

        } else if (AccountType.PERMANENT.equals(new_account)) {
            defaultText.setText("Enter your log-in details.");
            account_mode = LogInAuthAction.LOGIN;
        }
    }




    @FXML
    private void Set_Log_In_Mode() {
        set_mode (LogInAuthAction.LOGIN);
    }


    @FXML
    private void Set_Register_Mode() {
        set_mode (LogInAuthAction.REGISTER);
    }

    @FXML
    private void Set_Guest_Mode() {
        set_account_type (AccountType.GUEST);
        account_type = AccountType.GUEST;
    }

    @FXML
    private void Set_Perma_Mode() {
        set_account_type (AccountType.PERMANENT);
    }

}
