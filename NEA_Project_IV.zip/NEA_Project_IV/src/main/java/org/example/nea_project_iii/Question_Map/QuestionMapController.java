package org.example.nea_project_iii.Question_Map;


import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.example.nea_project_iii.Behind_The_Scenes.SceneManager;

import java.net.URL;
import java.util.ResourceBundle;


public class QuestionMapController {
    public ImageView Section1;
    public ImageView Section2;
    public ImageView Section3;

    public static int section_choice = 999;
        // Determines which section the user enters

    @FXML
    public void initialize(URL location, ResourceBundle resources) {
        load_section1("/org/example/nea_project_iii/Images_Folder/section1.png");
        load_section2("/org/example/nea_project_iii/Images_Folder/section2.png");
        load_section3("/org/example/nea_project_iii/Images_Folder/section3.png");
    }


    public void Topic1_ButtonClick() {
        SceneManager.SwitchToQuestionMapConfirmation();
        section_choice = 1;
    }

    public void Topic2_ButtonClick() {
        SceneManager.SwitchToQuestionMapConfirmation();
        section_choice = 2;
    }


    public void Topic3_ButtonClick() {
        SceneManager.SwitchToQuestionMapConfirmation();
        section_choice = 3;
    }


    public void Back() {
        SceneManager.SwitchToQuestionMapConfirmation();
        section_choice = 4;
    }

    public void load_section1(String image_name) {

        Image image = new Image(
                getClass().getResource(image_name).toExternalForm()
        );

        Section1.setImage(image);
    }

    public void load_section2 (String image_name) {
        Image image = new Image(
                getClass().getResource(image_name).toExternalForm()
        );
        Section2.setImage(image);
    }

    public void load_section3 (String image_name) {
        Image image = new Image(
                getClass().getResource(image_name).toExternalForm()
        );
        Section3.setImage(image);
    }

}