package org.example.nea_project_iii.Introduction;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.example.nea_project_iii.Behind_The_Scenes.SceneManager;

import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class IntroController implements Initializable {

    private int current_slide = 1;

    @FXML private ImageView ImageView;

    private static final int FIRST_SLIDE = 1;
    private static final int LAST_SLIDE = 5;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ImageView.setImage(load_slide(current_slide));
        ImageView.setX(50);
        ImageView.setY(25);
        ImageView.setFitHeight(450);
        ImageView.setFitWidth(500);
        ImageView.setPreserveRatio(true);
    }

    @FXML
    public void Backward() {
        if (current_slide <= 1) {
            current_slide = FIRST_SLIDE;
            return;
        }

        current_slide = current_slide - 1;
        ImageView.setImage(load_slide(current_slide));
    }

    @FXML
    public void Forward() {
        if (current_slide >= LAST_SLIDE) {
            SceneManager.SwitchToMainMenu();
            return; // Automatically progresses to Main Menu when all slides are read
        }
        current_slide = current_slide + 1;
        ImageView.setImage(load_slide(current_slide));
    }




    @FXML
    public void End() {
        SceneManager.SwitchToMainMenu();
    }


    private Image load_slide(int slide_number) {
        String path =
                "/org/example/nea_project_iii/Images_Folder/page_" + slide_number + ".png";
        return new Image(Objects.requireNonNull(getClass().getResourceAsStream(path),
                "Missing resource: " + path));
    }
}
