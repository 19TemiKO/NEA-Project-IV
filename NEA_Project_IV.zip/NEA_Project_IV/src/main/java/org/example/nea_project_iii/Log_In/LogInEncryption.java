package org.example.nea_project_iii.Log_In;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;


public class LogInEncryption {

    public static String[] EncryptionAlgorithm(String caught_username, String caught_password) {
        MessageDigest digest = null;
        try {
            digest = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        byte[] encrypted_password = digest.digest
                (Arrays.toString(caught_password.getBytes(StandardCharsets.UTF_8)).getBytes());
        byte[] encrypted_username = digest.digest
                (Arrays.toString(caught_username.getBytes(StandardCharsets.UTF_8)).getBytes());
        String[] user_details = new String[2];

            // To be completely honest, I didn't know how else to store the encrypted details.
                // I needed to pass both the username and password.
                // An array that could hold two values felt like a sensible solution.

        user_details[0] = Arrays.toString(encrypted_username);
        user_details[1] = Arrays.toString(encrypted_password);


        return user_details;
    }
}