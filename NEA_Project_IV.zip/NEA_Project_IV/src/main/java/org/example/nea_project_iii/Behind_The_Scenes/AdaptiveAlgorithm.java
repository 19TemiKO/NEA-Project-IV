package org.example.nea_project_iii.Behind_The_Scenes;


public class AdaptiveAlgorithm {

    private int difficulty = 1; // 1 = Easy, 2 = Medium, 3 = Hard
    private static int winning_streak = 0;
    private int losing_streak = 0;


    public void adjust_streak (boolean correct) {

        if (correct) {
            winning_streak = winning_streak + 1;
            losing_streak = 0;
            handle_difficulty();

        } else {
            losing_streak = losing_streak + 1;
            winning_streak = 0;
            }
        }


    private void handle_difficulty() {
        if (difficulty == 1 && winning_streak >= 3) {
            difficulty = 2; // Easy -> Medium
            winning_streak = 0;

        } else if (difficulty == 2 && winning_streak >= 5) {
            difficulty = 3; // Medium -> Hard
            winning_streak = 0;

        } else if (difficulty == 3 && losing_streak >= 3) {
            difficulty = 2; // Hard -> Medium
            losing_streak = 0;

        } else if (difficulty == 2 && losing_streak >= 5) {
            difficulty = 1; // Medium -> Easy
            losing_streak = 0;
        }
    }


    public int get_difficulty_int() {
        return difficulty;
    }

    public String get_difficulty_name() {
        return switch (difficulty) {
            case 1 -> "Easy";
            case 2 -> "Medium";
            case 3 -> "Hard";
            default -> "";
        };
    }

    public static int get_winning_streak() {
        return winning_streak;
    }

    public void set_difficulty (int difficulty) {
        this.difficulty = difficulty;
    }
}

