package org.example.nea_project_iii.Main_Menu;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.example.nea_project_iii.Behind_The_Scenes.SceneManager;

import java.net.URL;
import java.util.ResourceBundle;



public class MainMenuController implements Initializable {
    @FXML private ImageView ImageView;
    @FXML public static int menu_choice;



    @FXML public void initialize(URL location, ResourceBundle resources) {
        load_logo("/org/example/nea_project_iii/Images_Folder/JB_logo.png");
    }

    @FXML
    public void Question_Button_Click() {
        SceneManager.SwitchToMainMenuConfirmation();
        menu_choice = 0;
    }

    @FXML
    public void Settings_Button_Click() {
        SceneManager.SwitchToMainMenuConfirmation();
        menu_choice = 1;
    }


    @FXML
    public void Log_Out_Button_Click() {
        SceneManager.SwitchToMainMenuConfirmation();
        menu_choice = 2;
    }


    public void load_logo(String image_name) {
        Image image = new Image(
                getClass().getResource(image_name).toExternalForm()
        );
        ImageView.setImage(image);
    }
}