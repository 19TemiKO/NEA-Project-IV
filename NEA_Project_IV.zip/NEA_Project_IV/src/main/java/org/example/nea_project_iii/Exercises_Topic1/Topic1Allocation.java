package org.example.nea_project_iii.Exercises_Topic1;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import java.sql.SQLException;
import java.util.*;

import org.example.nea_project_iii.Behind_The_Scenes.AdaptiveAlgorithm;
import org.example.nea_project_iii.Behind_The_Scenes.SceneManager;
import org.example.nea_project_iii.Behind_The_Scenes.UserInfo;
import org.example.nea_project_iii.Log_In.LogInController;

import static org.example.nea_project_iii.Behind_The_Scenes.AccountType.PERMANENT;


public class Topic1Allocation {

    private static final int MAX_QUESTIONS = 15;

    private final Topic1Database database = new Topic1Database();
    private final AdaptiveAlgorithm adaptive = new AdaptiveAlgorithm();
    private final Random random = new Random();


    private Topic1Question current_question;
    private int questions_asked = 0;
    private final Set<Integer> asked_questions = new HashSet<>();

    @FXML private Label question_label, score_label, answer_label;
    @FXML private Button button1, button2, button3, button4;
    @FXML private TextField answer_field;
    @FXML private Button submit_button, leave_button, progress_button;
    @FXML private ProgressBar progress_bar;




    @FXML
    public void initialize() {

        if (LogInController.account_type == PERMANENT) {
            try {
                int user_id = UserInfo.get_current_user_id();
                int saved_difficulty = database.get_user_difficulty(user_id);
                adaptive.set_difficulty(saved_difficulty);

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } // Loads questions of a difficulty the user has last achieved.
        // For example, if they've completed an exercise and scored Easy, Easy questions are loaded

        update_score_label();
        load_next_question();
    }


    private void load_next_question() {
        answer_field.clear();
        answer_field.setDisable(true);

        if (questions_asked >= MAX_QUESTIONS) {
            end_quiz();
            return;
        }

        try {
            List<Topic1Question> questions = database.allocate_difficulty(adaptive.get_difficulty_int());
                // Creates a list of questions depending on the difficulty

            if (questions.isEmpty()) {
                question_label.setText("No more questions available.");
                return;
            }

            current_question = questions.get(random.nextInt(questions.size()));
            asked_questions.add(current_question.get_id());
            question_label.setText(current_question.get_question());


            String question_type = current_question.get_question_type().toUpperCase();

            if (question_type.equals("MC")) {
                set_MC();
            } else if (question_type.equals("TYPED")) {
                set_typed();}

            questions_asked = questions_asked + 1;
            progress_bar.setProgress((double) questions_asked / MAX_QUESTIONS);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    private void set_MC() {
        answer_field.setDisable(true);
        submit_button.setDisable(true);

        button1.setDisable(false);
        button2.setDisable(false);
        button3.setDisable(false);
        button4.setDisable(false);

        List<String> answers = new ArrayList<>();
        answers.add(current_question.get_correct());
        answers.add(current_question.get_incorrect1());
        answers.add(current_question.get_incorrect2());
        answers.add(current_question.get_incorrect3());

        Collections.shuffle (answers);
            // Shuffles the order of answers

        button1.setText(answers.get(0));
        button2.setText(answers.get(1));
        button3.setText(answers.get(2));
        button4.setText(answers.get(3));
    }

    private void set_typed() {
        button1.setDisable(true);
        button2.setDisable(true);
        button3.setDisable(true);
        button4.setDisable(true);

        answer_field.setDisable(false);
        submit_button.setDisable(false);
        progress_button.setDisable(false);
        answer_field.clear();
    }



    @FXML
    private void handle_mc (ActionEvent event) {
        Button clicked = (Button) event.getSource();
        check_answer(clicked.getText());
    }

    @FXML
    private void handle_typed() {
        String user_answer = answer_field.getText();
        if (user_answer == null || user_answer.trim().isEmpty()) {
            return;
        } check_answer (user_answer); }



    @FXML
    public void progress() {
        if (questions_asked >= MAX_QUESTIONS) {
            end_quiz(); }
        else {
            load_next_question();
            answer_field.clear();
        }
    }


    private void check_answer (String user_input) {
        button1.setDisable(true);
        button2.setDisable(true);
        button3.setDisable(true);
        button4.setDisable(true);
        submit_button.setDisable(true);

        String correct_answer = current_question.get_correct();

        boolean correct = user_input != null &&
                user_input.equalsIgnoreCase(correct_answer);

        if (correct) {
            answer_label.setText("Correct answer!");
            answer_label.setStyle("-fx-text-fill: green;");
            answer_label.setVisible(true);

        } else {
            answer_label.setText("Incorrect. Correct answer: " + correct_answer);
            answer_label.setStyle("-fx-text-fill: red;");
            answer_label.setVisible(true);
        }

        adaptive.adjust_streak(correct);
        update_score_label();
        answer_field.clear();
    }



    private void update_score_label() {
        score_label.setText(
                "Streak: " + AdaptiveAlgorithm.get_winning_streak() +
                " | Difficulty: " + adaptive.get_difficulty_name()
        );
    }



    private void end_quiz() {

        button1.setDisable(true);
        button2.setDisable(true);
        button3.setDisable(true);
        button4.setDisable(true);
        submit_button.setDisable(true);
        progress_button.setDisable(true);
        answer_field.setDisable(true);

        int final_difficulty = adaptive.get_difficulty_int();

        // Store for results screen
        UserInfo.set_last_difficulty(final_difficulty);

        if (LogInController.account_type == PERMANENT) {
            try {
                int user_id = UserInfo.get_current_user_id();
                database.update_user_difficulty(user_id, final_difficulty);
        // Updates the user difficulty depending on their progress
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        SceneManager.SwitchToResults();
    }



    @FXML
    private void leave() {
        SceneManager.SwitchToQuestionMap();
        // Their progress isn't saved.
    }
}