package org.example.nea_project_iii.Log_In;


public record LogInAuthResult(boolean success, Integer user_id, String message, LogInAuthAction login) {
    public static LogInAuthResult log_in_success(int user_id) {
        return new LogInAuthResult(true, user_id, "OK", LogInAuthAction.LOGIN);
    }

    public static LogInAuthResult log_in_fail(String message) {
        return new LogInAuthResult(false, null, message, LogInAuthAction.LOGIN);
    }
}

