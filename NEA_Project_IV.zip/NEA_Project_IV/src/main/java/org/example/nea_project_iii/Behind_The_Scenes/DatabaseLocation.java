package org.example.nea_project_iii.Behind_The_Scenes;

import java.sql.*;


public class DatabaseLocation {
    private static final String URL = "jdbc:sqlite:identifier.sqlite";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }
}
