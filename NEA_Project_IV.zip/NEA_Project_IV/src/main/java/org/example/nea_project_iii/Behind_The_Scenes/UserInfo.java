package org.example.nea_project_iii.Behind_The_Scenes;

import org.example.nea_project_iii.Log_In.LogInAuthAction;

import static org.example.nea_project_iii.Log_In.LogInController.account_mode;
import static org.example.nea_project_iii.Log_In.LogInController.account_type;

public class UserInfo {

    private static int current_user_id;
    private static int last_difficulty;
    private static String username_info;
    private static String password_info;
    private static AccountType type;
    private static LogInAuthAction mode;

    public static void set_current_user_id(int user_id) {
        current_user_id = user_id;
    }
    public static int get_current_user_id() {
        return current_user_id;
    }


    public static int get_last_difficulty() {
        return last_difficulty;
    }
    public static void set_last_difficulty(int end_difficulty) {
        last_difficulty = end_difficulty;
    }



    public static void set_username(String username_got) {
        username_info = username_got;
    }
    public static String get_username() {
        return username_info;
    }


    public static void set_password(String password_got) {
        password_info = password_got;
    }
    public static String get_password() {
        return password_info;
    }


    public static void set_account_type(AccountType type) {
        account_type = type;
    }
    public static AccountType get_account_type () {
        return type;
    }

    public static void set_account_mode (LogInAuthAction mode) {
        account_mode = mode;
    }
    public static LogInAuthAction get_account_mode () {
        return mode;
    }

}
