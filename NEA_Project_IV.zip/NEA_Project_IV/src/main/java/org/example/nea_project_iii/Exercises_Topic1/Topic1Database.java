package org.example.nea_project_iii.Exercises_Topic1;

import org.example.nea_project_iii.Behind_The_Scenes.DatabaseLocation;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Topic1Database {

    public int get_user_difficulty(int user_id) throws SQLException {

        String get_difficulty_sql = """
        SELECT topic1_difficulty
        FROM user_progress
        WHERE user_id = ?
        """;

        try (Connection connection = DatabaseLocation.getConnection();
             PreparedStatement statement = connection.prepareStatement(get_difficulty_sql)) {
            statement.setInt(1, user_id);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("topic1_difficulty");
            }
        }

        return 1; // default difficulty
    }


    public void update_user_difficulty(int user_id, int difficulty) throws SQLException {

        String update_difficulty_sql = """
        UPDATE user_progress
        SET topic1_difficulty = ?
        WHERE user_id = ?
        """;

        try (Connection connection = DatabaseLocation.getConnection();
             PreparedStatement statement = connection.prepareStatement(update_difficulty_sql)) {

            statement.setInt(1, difficulty);
            statement.setInt(2, user_id);

            statement.executeUpdate();
        }
    }



    public List<Topic1Question> allocate_difficulty(int difficulty) throws SQLException {

        List<Topic1Question> questions = new ArrayList<>();

        String get_question_difficulty = """
        SELECT question_id, question, correct_answer,
               incorrect_answer1, incorrect_answer2, incorrect_answer3, question_type
        FROM topic1
        WHERE difficulty = ?
        """;

        try (Connection connection = DatabaseLocation.getConnection();
             PreparedStatement get_ps = connection.prepareStatement(get_question_difficulty)) {

            get_ps.setInt(1, difficulty);

            ResultSet get_rs = get_ps.executeQuery();

            while (get_rs.next()) {

                Topic1Question question = new Topic1Question(
                        get_rs.getInt("question_id"),
                        get_rs.getString("question"),
                        get_rs.getString("correct_answer"),
                        get_rs.getString("incorrect_answer1"),
                        get_rs.getString("incorrect_answer2"),
                        get_rs.getString("incorrect_answer3"),
                        get_rs.getString("question_type")
                );

                questions.add(question);
            }
        }

        return questions;
    }
}