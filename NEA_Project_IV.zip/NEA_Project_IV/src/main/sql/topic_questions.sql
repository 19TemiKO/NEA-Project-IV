CREATE TABLE IF NOT EXISTS topic1 (
         question_id INTEGER PRIMARY KEY AUTOINCREMENT,
         difficulty INTEGER NOT NULL,
         question TEXT NOT NULL,
         correct_answer TEXT NOT NULL,
         incorrect_answer1 TEXT NOT NULL,
         incorrect_answer2 TEXT NOT NULL,
         incorrect_answer3 TEXT NOT NULL,
         question_type TEXT NOT NULL
);


INSERT INTO topic1 (question_id, difficulty, question, correct_answer, incorrect_answer1, incorrect_answer2,
                    incorrect_answer3, question_type)

VALUES
    (1, 1, 'Translate the following: "こんにちは"',
     'Hello', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (2, 1, 'Translate the following: "こんにちは"',
     'Hello', 'Goodbye', 'Good morning',
     'Good evening', 'MC'),

    (3, 1, 'Translate the following: "じゃあね"',
     'Goodbye', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (4, 1, 'Translate the following: "じゃあね"',
     'Goodbye', 'Good morning', 'Nice to meet you',
     'Hello', 'MC'),

    (5, 1, 'Translate the following: "おやすみ"',
     'Goodnight', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (6, 1, 'Translate the following: "おやすみ"',
     'Goodnight', 'Good evening', 'Good afternoon',
     'Good day', 'MC'),

    (7, 1, 'Translate the following: "おはよう"',
     'Good morning', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (8, 1, 'Translate the following: "おはよう"',
     'Good morning', 'Good day', 'Goodnight',
     'Goodbye', 'MC'),

    (9, 1, 'Translate the following: "こんばんは"',
     'Good evening', 'N/A', 'N/A',
     'Good afternoon', 'Typed'),

    (10, 1, 'Translate the following: "こんばんは"',
     'Good evening', 'Good morning', 'Goodnight',
     'Good afternoon', 'MC'),

    (11, 1, 'Translate the following: "はじめまして"',
     'Nice to meet you', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (12, 1, 'Translate the following: "はじめまして"',
     'Nice to meet you', 'See you again', 'Goodbye',
     'That was fun', 'MC'),

    (13, 1, 'Translate the following: "私はケンです"',
     'I am Ken', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (14, 1, 'Translate the following: "私はケンです"',
     'I am Ken', 'I am Hana', 'This is Courtney',
     'You are Simon', 'MC'),

    (15, 1, 'Translate the following: "私はハナです"',
     'I am Hana', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (16, 1, 'Translate the following: "私はハナです"',
     'I am Hana', 'I am John', 'I am Simon',
     'I am Ken', 'MC'),

    (17, 1, 'Translate the following: "どうぞよろしくお願いします"',
     'Nice to meet you', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (18, 1, 'Translate the following: "どうぞよろしくお願いします"',
     'Nice to meet you', 'Nice hearing from you', 'Hello',
     'Nice to catch up', 'MC'),

    (19, 1, 'Translate the following: "また明日ね"',
     'See you tomorrow', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (20, 1, 'Translate the following: "また明日ね"',
     'See you tomorrow', 'See you soon', 'See you later',
     'See you never', 'MC'),

    (21, '1', 'Translate the following: "さようなら"',
     'Goodbye', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (22, '1', 'Translate the following: "さようなら"',
     'Goodbye', 'Hello', 'Good afternoon',
     'Excuse me', 'MC');



INSERT INTO topic1 (question_id, difficulty, question, correct_answer, incorrect_answer1, incorrect_answer2,
                    incorrect_answer3, question_type)

VALUES
    (23, '2', 'Translate the following: "こんにちは、ハナです"',
     'Hello, I am Hana', 'Goodbye, I am Ken', 'Good evening, you are Hana.',
     'Good day, they are Ken.', 'MC'),

    (24, '2', 'Translate the following: "こんにちは、ハナです"',
     'Hello, I am Hana', 'N/A', 'N/A',
     'N/A.', 'Typed'),

    (25, '2', 'Translate the following: "こんばんは, はじめまして"',
     'Good evening, nice to meet you', 'Good day, see you later', 'Good morning, nice to meet you.',
     'Good afternoon.', 'MC'),

    (26, '2', 'Translate the following: "こんばんは はじめまして"',
     'Good evening, nice to meet you', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (27, '2', 'Translate the following: "おやすみなさい、ケント"',
     'Goodnight, Ken', 'Good morning, Ken', 'Good afternoon, Ken',
     'Good evening, Ken', 'MC'),

    (28, '2', 'Translate the following: "おやすみなさい、ケント"',
     'Goodnight, Ken', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (29, '2', 'Translate the following: "さようなら、また明日"',
     'Goodbye, see you tomorrow', 'Good morning, how are you?', 'Hello, Ken',
     'Good evening, see you on Wednesday', 'MC'),

    (30, '2', 'Translate the following: "さようなら、また明日"',
     'Goodbye, see you tomorrow', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (31, '2', 'Translate the following: "さようなら、また明日"',
     'Goodbye, see you tomorrow', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (41, '2', 'Translate the following: "こんにちは、初めまして"',
     'Hello, nice to meet you', 'Good evening, nice to meet you', 'Good morning, nice to see you',
     'Nice to meet you, hello', 'MC'),

    (32, '2', 'Translate the following: "こんにちは、初めまして"',
     'Hello, nice to meet you', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (33, '2', 'Translate the following: "初めまして、ケンです"',
     'Nice to meet you, I am Ken', 'Nice to meet you, I am Hana', 'Good afternoon, I am Ken',
     'Good afternoon, I am Hana', 'MC'),

    (34, '2', 'Translate the following: "こんにちは、初めまして"',
     'Hello, nice to meet you', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (35, '2', 'Translate the following: "初めまして、ケンです"',
     'Nice to meet you, I am Ken', 'Nice to meet you, I am Hana', 'Good afternoon, I am Ken',
     'Good afternoon, I am Hana', 'MC'),

    (36, '2', 'Translate the following: "初めまして、ケンです"',
     'Nice to meet you, I am Ken', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (37, '2', 'Translate the following: "こんにちは、ケンです"',
     'Hello, Ken', 'Goodbye, Hana', 'Good morning, Ken',
     'Good evening, Ken', 'MC'),

    (38, '2', 'Translate the following: "こんにちは、ケンです"',
     'Hello, Ken', 'N/A', 'N/A',
     'N/A', 'Typed'),

    (39, '2', 'Translate the following: "はじめまして, さようなら"',
     'Nice to meet you, goodbye', 'Goodbye, nice to meet you', 'Nice seeing you',
     'N/A', 'I will see you again'),

    (40, '2', 'Translate the following: "はじめまして, さようなら"',
     'Nice to meet you, goodbye', 'N/A', 'N/A',
     'N/A', 'Typed');



INSERT INTO topic1 (question_id, difficulty, question, correct_answer, incorrect_answer1, incorrect_answer2,
                        incorrect_answer3, question_type)

VALUES
    (43, '3', 'In what context would you use "さようなら [Saynora = Goodbye]"',
    'Formal situations', 'Informal situations', 'Leaving a friend',
    'Leaving work', 'MC'),

    (44, '3', 'In what context would you use "お疲れ様です (Otsukaresama desu)"',
     'Leaving work/Thank you for the work', 'Leaving school/Thank you for the education',
     'Leaving a restaurant/Thank you for the food', 'Leaving a hotel/Thank you for the accommodation',
     'MC'),

    (44, '3', 'In what context would you use "失礼します (Shitsurei shimasu)"',
     'Leaving work the presence of someone', 'Leaving a large group',
     'Leaving a garden', 'Leaving a building',
     'MC'),

    (45, '3', 'In what context would you use "じゃね (Ja ne)"',
     'Casually around friends', 'Formally in front of work colleagues',
     'To people you do not know', 'When leaving a group',
     'MC'),

    (46, '3', 'In what context would you use "またね (Mata ne)"',
     'Implied you will see the person again', 'Never',
     'Implied you will never see them again', 'Always',
     'MC'),

    (47, '3', 'In what context would you use バイバイ (Bai Bai) "',
     'Cheerful among children', 'Cheerful among teenagers',
     'Cheerful among adults', 'Cheerful among pensioners',
     'MC'),
;

-- medium is full sentences
-- hard involves context