SELECT users.username, users.password FROM users
WHERE user_id = 2
