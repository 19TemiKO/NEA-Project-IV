INSERT INTO topic1 (question_id, difficulty, question, correct_answer, incorrect_answer1, incorrect_answer2,
                    incorrect_answer3, question_type)

VALUES
    (43, '3', 'In what context would you use "さようなら [Saynora = Goodbye]"',
     'Formal situations', 'Informal situations', 'Leaving a friend',
     'Leaving work', 'MC'),

    (44, '3', 'In what context would you use "お疲れ様です (Otsukaresama desu)"',
     'Leaving work/Thank you for the work', 'Leaving school/Thank you for the education',
     'Leaving a restaurant/Thank you for the food', 'Leaving a hotel/Thank you for the accommodation',
     'MC'),

    (44, '3', 'In what context would you use "失礼します (Shitsurei shimasu)"',
     'Leaving work the presence of someone', 'Leaving a large group',
     'Leaving a garden', 'Leaving a building',
     'MC'),

    (45, '3', 'In what context would you use "じゃね (Ja ne)"',
     'Casually around friends', 'Formally in front of work colleagues',
     'To people you do not know', 'When leaving a group',
     'MC'),

    (46, '3', 'In what context would you use "またね (Mata ne)"',
     'Implied you will see the person again', 'Never',
     'Implied you will never see them again', 'Always',
     'MC'),

    (47, '3', 'In what context would you use バイバイ (Bai Bai) "',
     'Cheerful among children', 'Cheerful among teenagers',
     'Cheerful among adults', 'Cheerful among pensioners',
     'MC'),
;