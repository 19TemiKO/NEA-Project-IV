CREATE TABLE IF NOT EXISTS users (
     user_id INTEGER PRIMARY KEY AUTOINCREMENT,
     username TEXT NOT NULL UNIQUE,
     password TEXT NOT NULL
);

INSERT INTO users (
       username,
       password
)
VALUES (
        'test123',
        'test123'
);

SELECT * FROM users
ORDER BY user_id



