UPDATE users
SET username = 'something',
    password = 'something'
WHERE user_id = 1;